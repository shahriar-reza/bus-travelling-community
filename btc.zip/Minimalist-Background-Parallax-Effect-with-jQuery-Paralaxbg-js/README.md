# jquery-background-paralex-effect
## How to use:
#####1. Include paralaxbg.min.js to your project. Also, you have to include jQuery library in your project.
#####2.1 Add the class "paralaxbg" to element you want to have the paralax effect. 
#####2.2 Optionaly, add attribute "data-paralaxbg-speed" to that element and give it a value. Values close to 0 are give a faster speed. If is not addded this attribute, the default value is 20.
#####3. Call the function "initParalaxBg()" in your custom .js file or directly in your html page.

#### Demo: http://catalinteodorescu.github.io/jquery-background-paralex-effect/
