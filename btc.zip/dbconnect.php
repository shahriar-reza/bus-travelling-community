<?php
	
	$serverName="localhost";
	$userName="id7346618_msrrusel";
	$password="btc_system";
	$dbName="id7346618_btc_system";
	
	$conn= new mysqli($serverName,$userName,$password,$dbName);
	if($conn->connect_error)
	{
			die("connection failed".$conn->connect_error);
	}
