# TODO

* Extend the .get selector so it's possible to pass each seat id as a separate argument. Let's keep the array method for backward compatibility,
* Add some way for rebuilding the map
* Aria tests
* Seat SeatSet functions instead of plain Objects

